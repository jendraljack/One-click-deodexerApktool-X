#!/system/bin/sh
main="$(dirname $0)"
#######################
if [ ! -f $main/oat2dex-0.88.jar ]
then
echo "oat2dex-0.88.jar not found\nPlease download and then put in $main"
abort
return 1
fi
########################
echo "LB. multi Deodexer for mobile app"
sh $main/deodex.AllOdex.sh
sh $main/deodex_Framework.Oat.sh
sh $main/makefolderApk.sh
sh $main/makefolderJar.sh
sh $main/PakcingDexTo.sh
echo "LB work done.."
