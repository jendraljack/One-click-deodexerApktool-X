#!/system/bin/sh
echo "Kompres .dex ke dalam .jar....!!!!"
#export LD_LIBRARY_PATH=/data/data/per.pqy.apktool/apktool/lib: /data/data/per.pqy.apktool/apktool/openjdk/lib:$LD_LIBRARY_PATH
#in some targets,LD_PRELOAD will cause a error.
#export LD_PRELOAD=
#umask 000
bb="/data/local/busybox"
kpa="$($bb dirname "$@")"
apkdir="$($bb basename $kpa)"

echo "jar: $apkdir.jar"
echo "dex: $apkdir.dex"
echo "Renaming $apkdir.dex to classes.dex"
mv -f $kpa/$apkdir.dex $kpa/classes.dex
#/data/data/per.pqy.apktool/apktool/openjdk/bin/7za x -tzip "$2" META-INF 
/data/data/per.pqy.apktool/apktool/openjdk/bin/7za a -tzip $kpa/$apkdir.jar $kpa/classes.dex
echo "Packing dex to jar done"
echo "Enjoy...!!!!"
$bb rm $kpa/classes.dex
cd $kpa
mv -f $kpa/$apkdir.jar ../
