#!/system/bin/sh
packdir="$(dirname $0)"
echo "Masuk $packdir"
find $packdir -name "*.apk" -exec sh $packdir/inputDex2Apk.sh {} \;
find $packdir -name "*.jar" -exec sh $packdir/inputDex2Jar.sh {} \;
echo "Skrip dikustomisasi oleh limitb.realer"
