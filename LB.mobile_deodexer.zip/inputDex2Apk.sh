#!/system/bin/sh
echo "Kompres .dex ke dalam .apk....!!!!"
#export LD_LIBRARY_PATH=/data/data/per.pqy.apktool/apktool/lib: /data/data/per.pqy.apktool/apktool/openjdk/lib:$LD_LIBRARY_PATH
#in some targets,LD_PRELOAD will cause a error.
#export LD_PRELOAD=
#umask 000
bb="/data/local/busybox"
kpa="$($bb dirname "$@")"
apkdir="$($bb basename $kpa)"

echo "apk: $apkdir.apk"
echo "dex: $apkdir.dex"
echo "Renaming $apkdir.dex to classes.dex"
mv -f $kpa/$apkdir.dex $kpa/classes.dex
echo "Into $kpa..."
#/data/data/per.pqy.apktool/apktool/openjdk/bin/7za x -tzip "$2" META-INF 
/data/data/per.pqy.apktool/apktool/openjdk/bin/7za a -tzip $kpa/$apkdir.apk $kpa/classes.dex
echo "Packing dex to apk is done"
echo "Enjoy...!!!!"
$bb rm $kpa/classes.dex
