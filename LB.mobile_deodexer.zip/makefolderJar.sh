#!/bin/sh
makefolder="$(dirname $0)"
#########
find $makefolder/system -name "*.jar" > $makefolder/list.sh
busybox sed -i 's|.jar||g' $makefolder/list.sh
cat $makefolder/list.sh|busybox awk '{print "mkdir \""$0"\""}'|sh
cat $makefolder/list.sh|busybox awk '{print "cd "$0"\nmv ../\"$(basename "$0").jar\""" ./"}' > $makefolder/make.sh
cat $makefolder/list.sh|busybox awk '{print "cd "$0"\nmv ../\"$(basename "$0").dex\""" ./"}' >> $makefolder/make.sh
#find $makefolder -type d -exec sh $makefolder/masukanapk.sh {} \;
sh $makefolder/make.sh
echo "Memasukan jar dan dex ke folder sementara"
echo "Selesai"
cd $makefolder
rm ./make.sh
rm ./list.sh
##########